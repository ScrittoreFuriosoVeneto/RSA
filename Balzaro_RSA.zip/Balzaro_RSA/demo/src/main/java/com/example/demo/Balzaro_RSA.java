package com.example.demo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class Balzaro_RSA {

	public static boolean ControlloreNumPrimo(BigInteger num) {
        if (num.compareTo(BigInteger.TWO) < 0) {
            return false;
        }
        return num.isProbablePrime(40);
    }

    public static BigInteger generatePrime(int bitLength) {
        SecureRandom rand = new SecureRandom();
        BigInteger num_primo;
        do {
            num_primo = new BigInteger(bitLength, rand).setBit(0);
        } while (!ControlloreNumPrimo(num_primo));
        return num_primo;
    }

    public static BigInteger gcd(BigInteger a, BigInteger b) {
        while (!b.equals(BigInteger.ZERO)) {
            BigInteger temp = b;
            b = a.mod(b);
            a = temp;
        }
        return a;
    }

    public static BigInteger modInverse(BigInteger a, BigInteger m) {
        BigInteger m0 = m;
        BigInteger y = BigInteger.ZERO;
        BigInteger x = BigInteger.ONE;

        if (m.equals(BigInteger.ONE)) {
            return BigInteger.ZERO;
        }

        while (a.compareTo(BigInteger.ONE) > 0) {
            BigInteger q = a.divide(m);
            BigInteger t = m;

            m = a.mod(m);
            a = t;
            t = y;

            y = x.subtract(q.multiply(y));
            x = t;
        }

        if (x.compareTo(BigInteger.ZERO) < 0) {
            x = x.add(m0);
        }

        return x;
    }


    public static BigInteger[] generateKeyPair(int bitLength) {

        BigInteger p = generatePrime(bitLength / 2);
        BigInteger q = generatePrime(bitLength / 2);

        BigInteger n = p.multiply(q);
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

        BigInteger e = BigInteger.valueOf(65537);
        while (gcd(e, phi).compareTo(BigInteger.ONE) != 0) {
            e = e.add(BigInteger.TWO);
        }

        BigInteger d = modInverse(e, phi);

        return new BigInteger[] { e, n, d };
    }

    public static BigInteger encrypt(String message, BigInteger e, BigInteger n) {
        BigInteger m = new BigInteger(message.getBytes());
        return m.modPow(e, n);
    }

    public static String decrypt(BigInteger ciphertext, BigInteger d, BigInteger n) {
        
            BigInteger m = ciphertext.modPow(d, n);
            logger.warn("Il codice sembr avere problemi in questa fase con frasi molto lunghe.");
        return new String(m.toByteArray());
        
    }
    private static final Logger logger = LoggerFactory.getLogger(Balzaro_RSA.class);
    public static void main(String[] args) {
        try {
            int bitLength = 512;
            BigInteger[] keyPair = generateKeyPair(bitLength);
            BigInteger e = keyPair[0];
            BigInteger n = keyPair[1];
            BigInteger d = keyPair[2];

            File file_in_lecture = new File("dacriptare.txt");
            FileWriter myWriter = new FileWriter("criptato.txt");
            FileWriter myWriter_decriptato = new FileWriter("decriptato.txt");
            Scanner myReader = new Scanner(file_in_lecture);

            String message = "";
            
            while (myReader.hasNextLine()) {
                message = myReader.nextLine();
                BigInteger ciphertext = encrypt(message, e, n);
                myWriter.write(ciphertext.toString() + "\n");
                String decryptedMessage = decrypt(ciphertext, d, n);
                myWriter_decriptato.write(decryptedMessage + "\n"+"Chiave privata (d, n): (" + d + ", " + n + ")"+ "\n"+"Chiave pubblica (e, n): (" + e + ", " + n + ")");
            }

            myReader.close();
            myWriter.close();
            myWriter_decriptato.close();
            
        } catch (IOException e) {
            
            logger.error("Qualcosa non ha funzionato: " + e.getMessage());
        }
    }

}
